<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AuthorRules extends Model
{

    protected $table = 'author_rules';


}

