<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/6/14
 * Time: 17:39
 */

/*
 *  Internal    内部版本 - 自营虚拟主机
 *  Release     发售版本 - 对外授权
 *  Free        免费版本 - 免费
 * */
return [
    'versionType' => 'Free',
    'version' => '1.1.0',
];