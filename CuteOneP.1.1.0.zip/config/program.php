<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/6/8
 * Time: 7:56
 */
return [
    // 公共回调
    'redirectUrl' => env("redirectUrl",''),
    // OneDrive API接口
    'baseAuthUrl' => env("baseAuthUrl",''),
    'appUrl' => env("appUrl",''),
    //世纪互联 API接口
    'chinaAuthUrl' => env("chinaAuthUrl",''),
    'chinaAppUrl' => env("chinaAppUrl",''),
];