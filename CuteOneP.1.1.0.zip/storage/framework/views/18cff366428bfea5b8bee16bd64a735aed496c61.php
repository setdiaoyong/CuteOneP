<?php $__env->startSection('style'); ?>
    <style>
        .index {
            background: url("/images/index_bg.png") no-repeat;
            background-size: cover;
            width: 100%;
            height: 100%;
        }
        .infocon {
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,.2);
        }
        .infocon h1 {
            color: white;
        }
        .infocon .ad {
            margin-top: 15px;
            color: white;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="index">
        <div class="infocon">
            <div style="padding: 5%">
                <h1>
                    当你看到这个页面，证明你使用了CuteOne的PHP版本，CuteOneP
                </h1>
                
                    
                    
                    
                    
                    
                    
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\phpEnv\www\CuteOne\resources\views/admin/index/index.blade.php ENDPATH**/ ?>