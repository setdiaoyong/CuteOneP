<?php $__env->startSection('style'); ?>
    <style>
        .layui-carousel {
            background: #f3f3f3;
        }
        img {
            width: 100%;
            height: 200px;
        }
        h2 {
            margin: 10px;
        }
        .theme-info {
            margin: 10px;
            height: 45px;
            overflow: hidden;
        }
        .theme-excerpt {
            text-align: right;
            padding: 0 10px 10px 0;
        }
        .version {
            float: left;
            padding: 10px;
        }
        .author {
            float: left;
            padding: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="layui-fluid">
        <div class="layui-row layui-col-space15">
            <div class="layui-col-md12">
                <div class="layui-card">
                    <div class="layui-card-header">模块管理</div>
                    <div class="layui-row layui-form">
                        <?php if(count($data) != 0): ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="layui-col-md4">
                                    <div class="layui-card">
                                        <div class="layui-card-body">
                                            <div class="layui-carousel">
                                                <img src="https://images.weserv.nl/?url=<?php echo e($v['img']); ?>" alt="<?php echo e($v['title']); ?>">
                                                <h2 class="title">
                                                    <?php echo e($v['title']); ?>

                                                </h2>
                                                <div class="theme-info">
                                                    <p>
                                                        <?php echo e($v['description']); ?>

                                                    </p>
                                                </div>
                                                <div class="theme-excerpt">
                                                    <div class="version">
                                                        Version: <?php echo e($v['version']); ?>

                                                    </div>
                                                    <div class="author">
                                                        系统版本: <?php echo e($v['dependences']['core']); ?>

                                                    </div>
                                                    <div class="author">
                                                        By: <?php echo e($v['author']); ?>

                                                    </div>
                                                    <div class="layui-input-inline">
                                                        <?php echo $v['status']; ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="layui-card">
                                <div class="layui-card-body">
                                    <p style="text-align: center;font-size: 50px;padding: 10% 0;color: #ccc;">
                                        您还未安装任何模块
                                    </p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['form', 'layer'], function(){
            var $ = layui.$; //重点处
            //监听提交
            $('.install').on('click', function () {
                var title = $(this).data('title');
                var name = $(this).data('name');
                layer.confirm('确定安装此模块?'
                    ,function(index, layero){
                        $.ajax({
                            url: "/admin/application/modules/install"
                            ,type: "POST"
                            ,dataType: "json"
                            ,data: {"title":title, "name":name, "_token": "<?php echo e(csrf_token()); ?>"}
                            ,success: function (data) {
                                if(data.code==0){
                                    layer.msg('成功！', {icon: 1});
                                    location.reload();
                                    layer.close(index);
                                }else{
                                    layer.msg(data.msg);
                                    return false;
                                }
                            }
                        });
                    }
                );
            });
            $('.uninstall').on('click', function () {
                var name = $(this).data('name');
                layer.confirm('确定卸载此模块?'
                    ,function(index, layero){
                        $.ajax({
                            url: "/admin/application/modules/uninstall"
                            ,type: "POST"
                            ,dataType: "json"
                            ,data: {"name":name, "_token": "<?php echo e(csrf_token()); ?>"}
                            ,success: function (data) {
                                if(data.code==0){
                                    layer.msg('成功！', {icon: 1});
                                    location.reload();
                                    layer.close(index);
                                }else{
                                    layer.msg(data.msg);
                                    return false;
                                }
                            }
                        });
                    }
                );
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\phpEnv\www\CuteOne\resources\views/admin/modules/index.blade.php ENDPATH**/ ?>