<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="layui-fluid">
        <div class="layui-row layui-col-space15">
            <div class="layui-col-md12">
                <div class="layui-card">
                    <div class="layui-card-header">
                        文件列表
                    </div>
                    <div class="layui-card-body">
                        <table class="layui-hide" id="list-table" lay-filter="list-table">
                            <thead>
                            <tr>
                                <th lay-data="{field:'name', sort: true}">文件</th>
                                <th lay-data="{field:'size', width:100, sort: true}">大小</th>
                                <th lay-data="{field:'lastModifiedDateTime', width:200, sort: true}">修改时间</th>
                                <th lay-data="{field:'operation', width:160}">操作</th>
                            </tr>
                            </thead>
                            <tbody id="layer-photos">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if(array_key_exists('folder', $v)): ?>
                                            <a href="<?php echo e($current_url); ?>/<?php echo e(urlencode(str_replace('+', '%2B', $v['name']))); ?>">
                                                <i class="fa fa-folder"></i>
                                                <?php echo e($v['name']); ?>

                                            </a>
                                        <?php else: ?>
                                            <?php if($v['file']['mimeType'] == 'video/mp4'): ?>
                                                <a href="javasript:void(0);" onclick="openvideo('<?php echo e($v['thumbnails'][0]['large']['url']); ?>');">
                                                    <i class="fa fa-video-camera"></i>
                                                    <?php echo e($v['name']); ?>

                                                </a>
                                            <?php elseif($v['file']['mimeType'] == 'image/jpeg'): ?>
                                                <a href="javasript:void(0);" onclick="openimage('<?php echo e($v['thumbnails'][0]['large']['url']); ?>');">
                                                    <i class="fa fa-file-photo-o"></i>
                                                    <?php echo e($v['name']); ?>

                                                </a>
                                            <?php elseif($v['file']['mimeType'] == 'application/zip'): ?>
                                                <a href="javasript:void(0);">
                                                    <i class="fa fa-file-zip-o"></i>
                                                    <?php echo e($v['name']); ?>

                                                </a>
                                            <?php elseif($v['file']['mimeType'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'): ?>
                                                <a href="javasript:void(0);">
                                                    <i class="fa fa-file-word-o"></i>
                                                    <?php echo e($v['name']); ?>

                                                </a>
                                            <?php elseif($v['file']['mimeType'] == 'application/octet-stream'): ?>
                                                <a href="javasript:void(0);">
                                                    <i class="fa fa-font"></i>
                                                    <?php echo e($v['name']); ?>

                                                </a>
                                            <?php else: ?>
                                                <a href="javasript:void(0);">
                                                    <i class="fa fa-file"></i>
                                                    <?php echo e($v['name']); ?>

                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($v['size']); ?>

                                    </td>
                                    <td>
                                        <?php echo e($v['lastModifiedDateTime']); ?>

                                    </td>
                                    <td>
                                        <a class="layui-btn layui-btn-normal layui-btn-xs" href="javascript:void(0);" onclick="rename_files('<?php echo e($v['id']); ?>')">
                                            <i class="fa fa-edit"></i>
                                            重命名
                                        </a>
                                        <a class="layui-btn layui-btn-danger layui-btn-xs" href="javascript:void(0);" onclick="delete_files('<?php echo e($v['id']); ?>')">
                                            <i class="fa fa-recycle"></i>
                                            删除
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        layui.use(['layer', 'table'], function(){
            var $ = layui.$;
            var table = layui.table;
            // 静态表格
            table.init('list-table', {
                limit: 30
                ,page: true //开启分页
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\phpEnv\www\CuteOne\resources\views/admin/disk/file_list.blade.php ENDPATH**/ ?>