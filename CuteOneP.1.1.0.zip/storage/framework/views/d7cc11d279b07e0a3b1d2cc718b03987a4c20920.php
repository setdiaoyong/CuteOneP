<?php $__env->startSection('style'); ?>
    <style>
        .other_btn {
            position: absolute;
            left: 0;
        }
        .other_btn span {
            margin-left: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="mdui-container-fluid">
        <div class="mdui-toolbar nexmoe-item">
            <a href="/disk/<?php echo e($disk_id); ?>">根目录</a>/
            <?php $__currentLoopData = $crumbs_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($crumbs_url); ?>/<?php echo e(urlencode($v['path'])); ?>"><?php echo e($v['name']); ?></a>/
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="mdui-container-fluid">
        <div class="nexmoe-item">
            <div class="mdui-row">
                <ul class="mdui-list">
                    <li class="mdui-list-item th">
                        <div class="mdui-col-xs-12 mdui-col-sm-7">文件 <i class="mdui-icon material-icons icon-sort" data-table="name" data-sort="more">expand_more</i></div>
                        <div class="mdui-col-sm-3 mdui-text-right">修改时间 <i class="mdui-icon material-icons icon-sort" data-table="lastModifiedDateTime" data-sort="more">expand_more</i></div>
                        <div class="mdui-col-sm-2 mdui-text-right">大小 <i class="mdui-icon material-icons icon-sort" data-table="size" data-sort="more">expand_more</i></div>
                    </li>
                    <?php $__currentLoopData = $data['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mdui-list-item mdui-ripple">
                            <?php if($v->file_type == 'folder'): ?>
                                <a href="<?php echo e($current_url); ?>/<?php echo e(urlencode(str_replace('+', '%2B', $v->name))); ?>">
                                    <div class="mdui-col-xs-12 mdui-col-sm-7 mdui-text-truncate">
                                        <i class="mdui-icon material-icons">folder_open</i>
                                        <span><?php echo e($v->name); ?></span>
                                    </div>
                                    <div class="mdui-col-sm-3 mdui-text-right"><?php echo e($v->lastModifiedDateTime); ?></div>
                                    <div class="mdui-col-sm-2 mdui-text-right"><?php echo e($v->size); ?></div>
                                </a>
                            <?php elseif($v->file_type == 'image/jpeg' || $v->file_type == 'image/png'): ?>
                                <a href="javascript:void(0);">
                                    <div _src="/disk/thumbnails/<?php echo e($disk_id); ?>/<?php echo e($v->file_id); ?>" class="mdui-col-xs-12 mdui-col-sm-7 mdui-text-truncate lightboxurl" data-lightbox="lightbox">
                                        <i class="mdui-icon material-icons">image</i>
                                        <span><?php echo e($v->name); ?></span>
                                    </div>
                                    <div class="mdui-col-sm-3 mdui-text-right">
                                        <div class="other_btn">
                                            <span class="down_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">cloud_download</i>
                                            </span>
                                            <span class="link_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">link</i>
                                            </span>
                                        </div>
                                        <?php echo e($v->lastModifiedDateTime); ?>

                                    </div>
                                    <div class="mdui-col-sm-2 mdui-text-right"><?php echo e($v->size); ?></div>
                                </a>
                            <?php elseif($v->file_type == 'audio/mpeg' || $v->file_type == 'audio/x-flac' || $v->file_type == 'audio/x-wav' || $v->file_type == 'audio/mp4'): ?>
                                <a href="javascript:void(0);" class="<?php if( $webConfig['is_music'] == 1): ?>addMusicList <?php else: ?> video_open <?php endif; ?>" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                    <div class="mdui-col-xs-12 mdui-col-sm-7 mdui-text-truncate">
                                        <i class="mdui-icon material-icons">music_note</i>
                                        <span><?php echo e($v->name); ?></span>
                                    </div>
                                    <div class="mdui-col-sm-3 mdui-text-right">
                                        <div class="other_btn">
                                            <span class="down_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">cloud_download</i>
                                            </span>
                                            <span class="link_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">link</i>
                                            </span>
                                        </div>
                                        <?php echo e($v->lastModifiedDateTime); ?>

                                    </div>
                                    <div class="mdui-col-sm-2 mdui-text-right"><?php echo e($v->size); ?></div>
                                </a>
                            <?php elseif($v->file_type == 'video/mp4' || $v->file_type == 'video/x-matroska' || $v->file_type == 'application/octet-stream'): ?>
                                <a href="javascript:void(0);" class="video_open" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                    <div class="mdui-col-xs-12 mdui-col-sm-7 mdui-text-truncate">
                                        <i class="mdui-icon material-icons">videocam</i>
                                        <span><?php echo e($v->name); ?></span>
                                    </div>
                                    <div class="mdui-col-sm-3 mdui-text-right">
                                        <div class="other_btn">
                                            <span class="down_file down_file_icon"  data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">cloud_download</i>
                                            </span>
                                            <span class="link_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">link</i>
                                            </span>
                                        </div>
                                        <?php echo e($v->lastModifiedDateTime); ?>

                                    </div>
                                    <div class="mdui-col-sm-2 mdui-text-right"><?php echo e($v->size); ?></div>
                                </a>
                            <?php elseif($v->file_type == 'application/msword' || $v->file_type == 'application/vnd.ms-excel' || $v->file_type == 'application/application/pdf'): ?>
                                <a href="javascript:void(0);" class="open_word" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                    <div class="mdui-col-xs-12 mdui-col-sm-7 mdui-text-truncate">
                                        <i class="mdui-icon material-icons">description</i>
                                        <span><?php echo e($v->name); ?></span>
                                    </div>
                                    <div class="mdui-col-sm-3 mdui-text-right">
                                        <div class="other_btn">
                                            <span class="down_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">cloud_download</i>
                                            </span>
                                            <span class="link_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">link</i>
                                            </span>
                                        </div>
                                        <?php echo e($v->lastModifiedDateTime); ?>

                                    </div>
                                    <div class="mdui-col-sm-2 mdui-text-right"><?php echo e($v->size); ?></div>
                                </a>
                            <?php elseif($v->file_type == 'application/zip'): ?>
                                <a href="javascript:void(0);" class="down_file" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                    <div class="mdui-col-xs-12 mdui-col-sm-7 mdui-text-truncate">
                                        <i class="mdui-icon material-icons">view_day</i>
                                        <span><?php echo e($v->name); ?></span>
                                    </div>
                                    <div class="mdui-col-sm-3 mdui-text-right">
                                        <div class="other_btn">
                                            <span class="down_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">cloud_download</i>
                                            </span>
                                            <span class="link_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">link</i>
                                            </span>
                                        </div>
                                        <?php echo e($v->lastModifiedDateTime); ?>

                                    </div>
                                    <div class="mdui-col-sm-2 mdui-text-right"><?php echo e($v->size); ?></div>
                                </a>
                            <?php else: ?>
                                <a href="javascript:void(0);" class="down_file" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                    <div class="mdui-col-xs-12 mdui-col-sm-7 mdui-text-truncate">
                                        <i class="mdui-icon material-icons">view_day</i>
                                        <span><?php echo e($v->name); ?></span>
                                    </div>
                                    <div class="mdui-col-sm-3 mdui-text-right">
                                        <div class="other_btn">
                                            <span class="down_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">cloud_download</i>
                                            </span>
                                            <span class="link_file down_file_icon" data-disk="<?php echo e($disk_id); ?>" data-id="<?php echo e($v->file_id); ?>" data-name="<?php echo e($v->name); ?>">
                                                    <i class="mdui-icon material-icons">link</i>
                                            </span>
                                        </div>
                                        <?php echo e($v->lastModifiedDateTime); ?>

                                    </div>
                                    <div class="mdui-col-sm-2 mdui-text-right"><?php echo e($v->size); ?></div>
                                </a>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="page-box">
                    <ul>
                        <li>
                            <span data-page="1" class="page-click">
                                首页
                            </span>
                        </li>
                        <?php $__currentLoopData = $data['pagination']['page']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($v == '...'): ?>
                                <li style="width: 20px;line-height: 30px;">
                                    ...
                                </li>
                            <?php else: ?>
                                <li class="<?php if($v == $data['pagination']['now_page']): ?> current <?php endif; ?>">
                                    <span data-page="<?php echo e($v); ?>" class="<?php if($v != $data['pagination']['now_page']): ?> page-click <?php endif; ?>">
                                        <?php echo e($v); ?>

                                    </span>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <i class="allpage">
                                共 <?php echo e($data['pagination']['count']); ?> 页
                            </i>
                        </li>
                        <li>
                            <span data-page="<?php echo e($data['pagination']['count']); ?>" class="page-click">
                                尾页
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.default.public.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\phpEnv\www\CuteOne\resources\views/front/default/disk/index.blade.php ENDPATH**/ ?>